# vypsat nasobilku (na kazdem radku deset soucinu)

(1..10).each do |i|
  (1.,10).each do |j|
    print "#{a} * #{b} = #{a*a} "
  end
  puts
end
